
<?php

// Handle offer submission.
function handle_make_an_offer_submission() {
    if (isset($_POST['offer_price']) && isset($_POST['product_id'])) {
        $offer_price = sanitize_text_field($_POST['offer_price']);
        $product_id = intval($_POST['product_id']);
        $comments = sanitize_textarea_field($_POST['comments']);

        $offer_data = [
            'post_type'    => 'offer',
            'post_title'   => "Offer for Product ID: $product_id",
            'post_content' => $comments,
            'post_status'  => 'pending',
            'meta_input'   => [
                '_offer_price' => $offer_price,
                '_product_id'  => $product_id,
                '_buyer_id'    => get_current_user_id(),
            ],
        ];
        wp_insert_post($offer_data);

        // Send email notification to the seller.
        send_offer_email_to_seller($product_id, $offer_price, $comments);

        wp_redirect(get_permalink($product_id));
        exit;
    }
}
add_action('admin_post_make_an_offer', 'handle_make_an_offer_submission');
add_action('admin_post_nopriv_make_an_offer', 'handle_make_an_offer_submission');
