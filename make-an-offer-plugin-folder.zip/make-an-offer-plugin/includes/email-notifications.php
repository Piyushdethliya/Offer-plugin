
<?php

function send_offer_email_to_seller($product_id, $offer_price, $comments) {
    $seller_email = get_the_author_meta('user_email', get_post_field('post_author', $product_id));
    $subject = "New Offer Received for Product ID: $product_id";
    $message = "An offer of $$offer_price has been made for your product. Comments: $comments";
    wp_mail($seller_email, $subject, $message);
}
