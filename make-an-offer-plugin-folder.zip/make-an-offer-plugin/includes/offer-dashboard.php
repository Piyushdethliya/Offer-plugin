
<?php

// Display offers in the seller's dashboard.
function display_offer_dashboard() {
    // Query offers for the current seller's products.
    $seller_id = get_current_user_id();
    $offers = get_posts([
        'post_type'   => 'offer',
        'meta_key'    => '_seller_id',
        'meta_value'  => $seller_id,
        'post_status' => 'pending',
    ]);

    echo '<div class="offer-dashboard">';
    echo '<h2>Offers Received</h2>';
    foreach ($offers as $offer) {
        $offer_price = get_post_meta($offer->ID, '_offer_price', true);
        $product_id = get_post_meta($offer->ID, '_product_id', true);
        echo "<p>Product ID: $product_id, Offer: $$offer_price</p>";
        echo '<button class="accept-offer">Accept</button>';
        echo '<button class="reject-offer">Reject</button>';
    }
    echo '</div>';
}
add_action('admin_menu', function () {
    add_menu_page('Offer Dashboard', 'Offer Dashboard', 'manage_woocommerce', 'offer-dashboard', 'display_offer_dashboard');
});
