
<?php
/*
Plugin Name: Make an Offer for WooCommerce
Description: Adds a "Make an Offer" button for negotiation functionality between buyers and sellers in WooCommerce.
Version: 1.0
Author: Your Name
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define plugin constants.
define('MAKE_AN_OFFER_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MAKE_AN_OFFER_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include necessary files.
include_once MAKE_AN_OFFER_PLUGIN_DIR . 'includes/offer-form-handler.php';
include_once MAKE_AN_OFFER_PLUGIN_DIR . 'includes/offer-dashboard.php';
include_once MAKE_AN_OFFER_PLUGIN_DIR . 'includes/email-notifications.php';
include_once MAKE_AN_OFFER_PLUGIN_DIR . 'includes/utilities.php';

// Enqueue scripts and styles.
function make_an_offer_enqueue_assets() {
    wp_enqueue_style('make-an-offer-styles', MAKE_AN_OFFER_PLUGIN_URL . 'assets/css/styles.css');
    wp_enqueue_script('make-an-offer-scripts', MAKE_AN_OFFER_PLUGIN_URL . 'assets/js/scripts.js', ['jquery'], false, true);
}
add_action('wp_enqueue_scripts', 'make_an_offer_enqueue_assets');

// Add "Make an Offer" button to product pages.
function add_make_an_offer_button() {
    global $product;
    if (get_post_meta($product->get_id(), '_enable_make_offer', true) === 'yes') {
        echo '<button class="make-an-offer-button">Make an Offer</button>';
    }
}
add_action('woocommerce_after_add_to_cart_button', 'add_make_an_offer_button');
