
jQuery(document).ready(function ($) {
    $(".make-an-offer-button").on("click", function () {
        alert("Offer functionality will be implemented here!");
    });
});
